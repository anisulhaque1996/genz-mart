import React from 'react';

const Header = () => {
  return (
    <header style={{ padding: '1rem', background: '#333', color: '#fff' }}>
      <h2>Gen Z Mart 🛒</h2>
    </header>
  );
};

export default Header;
import React from 'react';

const Footer = () => {
  return (
    <footer style={{ marginTop: '20px', textAlign: 'center', padding: '10px', background: '#f1f1f1' }}>
      <p>&copy; 2026 Gen Z Mart. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
import React from 'react';
import Header from './components/Header'; 
import Footer from './components/Footer'; 
import './App.css';

function App() {
  return (
    <div className="App">
      <Header />
      
      <main style={{ padding: '20px' }}>
        <h1>Gen Z Mart - এ স্বাগতম</h1>
        <p>আপনার প্রোজেক্ট এখন লাইভ হতে শুরু করেছে।</p>
      </main>

      <Footer />
    </div>
  );
}

export default App;